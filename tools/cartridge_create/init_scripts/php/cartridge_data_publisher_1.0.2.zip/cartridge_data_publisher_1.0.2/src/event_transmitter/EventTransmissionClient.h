/* 
 * File:   EventTransmissionClient.h
 * Author: isuru
 *
 * Created on February 11, 2013, 11:01 PM
 */

#ifndef EVENTTRANSMISSIONCLIENT_H
#define	EVENTTRANSMISSIONCLIENT_H

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp> 
#include <transport/TSocket.h>
#include <thrift/transport/TSSLSocket.h>
#include <transport/TBufferTransports.h>
//#include <protocol/TProtocol.h>
#include <protocol/TBinaryProtocol.h>
#include "gen/ThriftSecureEventTransmissionService.h"
#include "../ssl_handler/SSLHandler.h"
#include "../context/RemoteContext.h"
#include "../event/Event.h"
#include "../global_constants/Globals.h"

using namespace std;
using namespace apache::thrift; 
using namespace apache::thrift::protocol;
using namespace apache::thrift::transport;

class SecureEventTransmitter {
public:
    SecureEventTransmitter(boost::shared_ptr<SSLHandler> sslHandler,         
                           boost::shared_ptr<RemoteContext> remoteCtx);
    SecureEventTransmitter(const SecureEventTransmitter& orig);
    virtual ~SecureEventTransmitter();
    
    string createSession ();
    void terminateSession (string sessionId);
    string defineStream (string& sessionId, string streamDef);
    void publishEvent (boost::shared_ptr<Event> event, string& sessionId, string streamId);
    void terminateTransmitter ();
    
private:
    boost::shared_ptr<ThriftSecureEventTransmissionServiceClient> eventTransmissionClient;
    boost::shared_ptr<TSocket> socket;
    boost::shared_ptr<TTransport> transport;
    boost::shared_ptr<TProtocol> protocol;
    boost::shared_ptr<SSLHandler> sslHandler;
    boost::shared_ptr<RemoteContext> remoteCtx;
    
    void createSocket ();
    void createTransport ();
    void createProtocol ();
    void createPublisherClient ();
    void initializeTransmitter ();
    void reInitializeTransmitter ();
    void openConnection ();
    void reOpenConnection ();
    void openSocket ();
    bool isSocketOpen ();
    void closeSocket ();
    void openTransport ();
    bool isTransportOpen ();
    void closeTransport ();
    string reInitSession ();
    void doPublishingEvent (boost::shared_ptr<Event> event, string& sessionId, string streamId);
    void deallocateMemory ();
};

void pause (int duration);

#endif	/* EVENTTRANSMISSIONCLIENT_H */

