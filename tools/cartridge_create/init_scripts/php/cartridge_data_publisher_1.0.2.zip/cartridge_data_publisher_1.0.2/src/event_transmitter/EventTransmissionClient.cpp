/* 
 * File:   EventTransmissionClient.cpp
 * Author: isuru
 * 
 * Created on February 11, 2013, 11:01 PM
 */

#include "EventTransmissionClient.h"

SecureEventTransmitter::SecureEventTransmitter(boost::shared_ptr<SSLHandler> sslHandler, 
                                               boost::shared_ptr<RemoteContext> remoteCtx) {
    this->sslHandler = sslHandler;
    this->remoteCtx = remoteCtx; 
    initializeTransmitter();
}

SecureEventTransmitter::SecureEventTransmitter(const SecureEventTransmitter& orig) {
}

SecureEventTransmitter::~SecureEventTransmitter() {
    deallocateMemory();
}

void SecureEventTransmitter::initializeTransmitter() {
    createSocket();
    createTransport();
    createProtocol();
    createPublisherClient();
}

void SecureEventTransmitter::reInitializeTransmitter() {
    printf("[ INFO ] : Re-initializing event transmitter \n");
    initializeTransmitter();
}

void SecureEventTransmitter::createSocket() {
    socket = sslHandler->getSocketFactory()->createSocket(remoteCtx->getHost(), remoteCtx->getPort());
    assert(socket);
    printf("[ INFO ] : PublisherAgent socket created \n");
}

void SecureEventTransmitter::createTransport() {
    transport = boost::shared_ptr<TTransport>(new TBufferedTransport(socket));
    assert(transport);
    printf("[ INFO ] : PublisherAgent transport initialized \n");
}

void SecureEventTransmitter::createProtocol() {
    protocol = boost::shared_ptr<TProtocol>(new TBinaryProtocol(transport));
    assert(protocol);
    printf("[ INFO ] : PublisherAgent protocol initialized \n");
}

void SecureEventTransmitter::createPublisherClient() {
    eventTransmissionClient = boost::shared_ptr<ThriftSecureEventTransmissionServiceClient>(new ThriftSecureEventTransmissionServiceClient(protocol));
    assert(eventTransmissionClient);
    printf("[ INFO ] : PublisherAgent client created \n");
}

void SecureEventTransmitter::openConnection() {
    if(!isSocketOpen())
        openSocket();
    if(!isTransportOpen())
        openTransport(); 
}

void SecureEventTransmitter::reOpenConnection() {
    openConnection();
}

void SecureEventTransmitter::openSocket() {
    try {
        socket->open();
        printf("[ INFO ] : PublisherAgent socket opened \n");
    } catch (const TException& tx) {
        printf("[ ERROR ] : Socket open failure - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        for (int attempts = 1 ; attempts <= REATTEMPTS ; attempts++) {
            printf("[ INFO ] : Re-attempt %d \n", attempts);
            try {
                socket->open();
                break;
            } catch (const TException& tx){
                if(attempts == REATTEMPTS)
                    throw;
                else {
                    pause(20);
                }
            }
        }
    }
}

bool SecureEventTransmitter::isSocketOpen() {
    return socket->isOpen();
}

void SecureEventTransmitter::closeSocket() {
    try {
        socket->close();
        printf("[ INFO ] : PublisherAgent socket closed \n");
    } catch (const TException& tx) {
        //throw custom exception
        printf("[ ERROR ] : Socket close failure - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        throw;
    }
}

void SecureEventTransmitter::openTransport() {
    try {
        transport->open();
        printf("[ INFO ] : PublisherAgent transport opened \n");
    } catch (const TException& tx) {
        printf("[ ERROR ] : Transport open failure - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        for (int attempts = 1 ; attempts <= REATTEMPTS ; attempts++) {
            printf("[ INFO ] : Re-attempt %d \n", attempts);
            try {
                transport->open();
                break;
            } catch (const TException& tx){
                if(attempts == REATTEMPTS)
                    throw;
                else {
                    pause(20);
                }
            }
        }
    }
}

bool SecureEventTransmitter::isTransportOpen() {
    return transport->isOpen();
}

void SecureEventTransmitter::closeTransport() {
    try {
        transport->close();
        printf("[ INFO ] : PublisherAgent transport closed \n");
    } catch (const TException& tx) {
        //throw custom exception
        printf("[ ERROR ] : Transport close failure - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        //throw;
    }
}

string SecureEventTransmitter::createSession() {
    openConnection();
    
    string sessionId = "";

    try {
        eventTransmissionClient->connect(sessionId, remoteCtx->getUserName(), remoteCtx->getPassword());
        
    } catch (const ThriftAuthenticationException& tx) {
        printf("[ ERROR ] : Authentication failure - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        throw;
        
    } catch (const TException& tx) {
        printf("[ ERROR ] : Error creating session - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        reInitializeTransmitter(); 
        reOpenConnection();
        eventTransmissionClient->connect(sessionId, remoteCtx->getUserName(), remoteCtx->getPassword());
        //throw; throw a custom exception
    }
    return sessionId;
}

void SecureEventTransmitter::terminateSession(string sessionId) {
    try {
        eventTransmissionClient->disconnect(sessionId);
    } catch (const TException& tx) {
        printf("[ ERROR ] : Error terminating session - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
    }
}

string SecureEventTransmitter::defineStream(string& sessionId, string streamDef) { //can cache stream def since its no changing
        
    string streamId;
    try {
        eventTransmissionClient->defineStream(streamId, sessionId, streamDef);
        
    } catch (const ThriftDifferentStreamDefinitionAlreadyDefinedException& tx) {
        printf("[ ERROR ] : Different stream already exists - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        throw;
        
    } catch (const ThriftMalformedStreamDefinitionException& tx) {
        printf("[ ERROR ] : Malformed stream definition - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        throw;
        
    } catch (const ThriftStreamDefinitionException& tx) {
        printf("[ ERROR ] : Stream definition incorrect - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        throw;
        
    } catch (const ThriftSessionExpiredException& tx) {
        printf("[ ERROR ] : Session has expired - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        sessionId = reInitSession();
        eventTransmissionClient->defineStream(streamId, sessionId, streamDef);
        //throw; throw custom session if needed
        
    } catch (const TException& tx) {
        printf("[ ERROR ] : Error defining stream - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        reInitializeTransmitter();
        reOpenConnection();
        sessionId = reInitSession();
        eventTransmissionClient->defineStream(streamId, sessionId, streamDef);
        //throw; throw custom session if needed
    }
    
    return streamId;
}

void SecureEventTransmitter::publishEvent(boost::shared_ptr<Event> event, string& sessionId, string streamId) {
    
    try {
        doPublishingEvent(event, sessionId, streamId);
        
    } catch (const ThriftUndefinedEventTypeException& tx) {
        printf("[ ERROR ] : Undefined event type - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        event.reset();
        throw;

    } catch (const ThriftSessionExpiredException& tx) {
        printf("[ ERROR ] : Session has expired - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        sessionId = reInitSession();
        doPublishingEvent(event, sessionId, streamId);
        event.reset();
        //throw; throw custom exception if needed
        
    } catch (const TException& tx) {
        printf("[ ERROR ] : Failed to publish data - %s { %s %d } \n", tx.what(), __FILE__, __LINE__);
        reInitializeTransmitter();
        reOpenConnection();
        sessionId = reInitSession();
        doPublishingEvent(event, sessionId, streamId);
        event.reset();
        //throw; throw custom exception if needed
    }
    
    event.reset();
}

void SecureEventTransmitter::doPublishingEvent(boost::shared_ptr<Event> event, string& sessionId, string streamId) {
    
    ThriftEventBundle eventBundle;
    vector<long> logInfoLongVector;
    vector<string> logInfoStringVector;
    
    //populating the declared vectors with the relevant data types
    logInfoStringVector.push_back(streamId);
    logInfoLongVector.push_back(event->getTimeStamp());//timestamp
    
    logInfoStringVector.push_back(event->getTenantName());//client type
    logInfoStringVector.push_back(event->getTenantIdAsString());//tenant id
    logInfoStringVector.push_back("N/A");//server name
    logInfoStringVector.push_back("N/A");//app name
    logInfoLongVector.push_back(event->getTimeStamp());//time stamp
    logInfoStringVector.push_back("N/A");//priority
    logInfoStringVector.push_back(event->getMessage());//message
    logInfoStringVector.push_back("N/A"); //logger
    logInfoStringVector.push_back(event->getLocalIpAddress());//ip
    logInfoStringVector.push_back(event->getInstance());//instance
    logInfoStringVector.push_back("N/A");//stack trace
    
    //set the payload data vectors to the event bundle
    eventBundle.__set_longAttributeList(logInfoLongVector);
    eventBundle.__set_stringAttributeList(logInfoStringVector);

    eventBundle.__set_sessionId(sessionId);
    eventBundle.__set_eventNum(1);
    
    eventTransmissionClient->publish(eventBundle);
}

string SecureEventTransmitter::reInitSession() {
    printf("[ INFO ] : Re-initializing session \n");
    return createSession ();
}

void SecureEventTransmitter::terminateTransmitter() {
    closeTransport();
    closeSocket();
}

void pause (int duration) {
    boost::system_time time = boost::get_system_time();
    time += boost::posix_time::seconds(duration); 
    boost::this_thread::sleep(time);
}

void SecureEventTransmitter::deallocateMemory() {
    eventTransmissionClient.reset();
    protocol.reset();
    transport.reset();
    socket.reset();
    sslHandler.reset();
    sslHandler.reset();
}
