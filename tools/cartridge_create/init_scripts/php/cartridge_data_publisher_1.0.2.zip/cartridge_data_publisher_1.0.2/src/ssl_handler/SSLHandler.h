/* 
 * File:   SSLHandler.h
 * Author: isuru
 *
 * Created on February 13, 2013, 7:42 PM
 */

#ifndef SSLHANDLER_H
#define	SSLHANDLER_H

#include <iostream>
#include <thrift/Thrift.h>
#include <thrift/transport/TSSLSocket.h>
#include <boost/shared_ptr.hpp>

using namespace std;
using namespace apache::thrift;
using namespace apache::thrift::transport;

class SSLHandler {
public:
    SSLHandler(bool authenticate);
    SSLHandler(const SSLHandler& orig);
    virtual ~SSLHandler();
    
    void initiallize (string privateKey, string publicCertificate, string trustedCert, string cipher);
    void setAccessManager (boost::shared_ptr<AccessManager> accessManager);
    boost::shared_ptr<TSSLSocketFactory> getSocketFactory ();
    
private:
    const char* privateKey;
    const char* publicCertificate;
    const char* trustedCert;
    const char* cipher;
    boost::shared_ptr<TSSLSocketFactory> socketFactory;
    boost::shared_ptr<AccessManager> accessManager;
    
    void initSSL ();
    void initOwnCertificate ();
    void initPrivateKey ();
    void initTrustedCertificate ();
    void initCipher ();
    void deallocateMemory ();
};

#endif	/* SSLHANDLER_H */

