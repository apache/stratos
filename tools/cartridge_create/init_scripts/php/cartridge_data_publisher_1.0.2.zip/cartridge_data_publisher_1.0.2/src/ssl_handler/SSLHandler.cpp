/* 
 * File:   SSLHandler.cpp
 * Author: isuru
 * 
 * Created on February 13, 2013, 7:42 PM
 */

#include "SSLHandler.h"

SSLHandler::SSLHandler(bool authenticate) {
    socketFactory = boost::shared_ptr<TSSLSocketFactory>(new TSSLSocketFactory());
    socketFactory->authenticate(authenticate);
    socketFactory->server(false);
    assert(socketFactory);
}

SSLHandler::SSLHandler(const SSLHandler& orig) {
}

SSLHandler::~SSLHandler() {
    deallocateMemory();
}

void SSLHandler::initiallize(string privateKey, string publicCertificate, string trustedCert, string cipher) {
    this->privateKey = privateKey.c_str();
    this->publicCertificate = publicCertificate.c_str();
    this->trustedCert = trustedCert.c_str();
    this->cipher = cipher.c_str();
    initSSL();
}

void SSLHandler::setAccessManager(boost::shared_ptr<AccessManager> accessManager) {
    this->accessManager = accessManager;
    socketFactory->access(accessManager);
}

boost::shared_ptr<TSSLSocketFactory> SSLHandler::getSocketFactory() {
    return socketFactory;
}

void SSLHandler::initSSL() {
    initPrivateKey();
    initOwnCertificate();
    initTrustedCertificate();
    initCipher();
}

void SSLHandler::initPrivateKey() {
    try {
        socketFactory->loadPrivateKey(privateKey);
    } catch (const TException& tx) {
        printf("[ ERROR ] : %s { %s %d } - Private key initialization failure : \n", tx.what(), __FILE__, __LINE__);
        throw;
    }
}

void SSLHandler::initOwnCertificate() {
    try {
        socketFactory->loadCertificate(publicCertificate);
    } catch (const TException& tx) {
        printf("[ ERROR ] : %s { %s %d } - Public certificate initialization failure : \n", tx.what(), __FILE__, __LINE__);
        throw;
    }
}

void SSLHandler::initTrustedCertificate() {
    try {
        socketFactory->loadTrustedCertificates(trustedCert);
    } catch (const TException& tx) {
        printf("[ ERROR ] : %s { %s %d } - Trusted certificate initialization failure : \n", tx.what(), __FILE__, __LINE__);
        throw;
    }
}

void SSLHandler::initCipher() {
    try {
        socketFactory->ciphers(cipher);
    } catch (const TException& tx) {
        printf("[ ERROR ] : %s { %s %d } - cipher initialization failure \n", tx.what(), __FILE__, __LINE__);
        throw;
    }
}

void SSLHandler::deallocateMemory() {
    socketFactory.reset();
    accessManager.reset();
}