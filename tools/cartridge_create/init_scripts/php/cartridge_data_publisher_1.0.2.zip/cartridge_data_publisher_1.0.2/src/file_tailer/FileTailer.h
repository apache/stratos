/* 
 * File:   FileTailer.h
 * Author: isuru
 *
 * Created on March 17, 2013, 12:33 AM
 */

#ifndef FILETAILER_H
#define	FILETAILER_H

#include <iostream>
#include <list>
#include <boost/algorithm/string.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp> 
#include "../manager/PublisherAgentManager.h"
#include "../ssl_handler/SSLHandler.h"
#include "../publisher/DataPublisher.h"
#include "../config/Configuration.h"

using namespace std;

class FileTailer {
public:
    FileTailer(boost::shared_ptr<PublisherAgentManager> publisherAgentManager, 
               boost::shared_ptr<SSLHandler> sslHandler, 
               list<string> files);
    FileTailer(const FileTailer& orig);
    virtual ~FileTailer();

    void start ();
private:    
    boost::shared_ptr<boost::thread_group> processingThreadGroup;
    boost::shared_ptr<PublisherAgentManager> publisherAgentManager;
    boost::shared_ptr<SSLHandler> sslHandler;
    list<string> files;
    
    void deallocateMemory ();
    
    friend void process (string filePath, FileTailer* fileTailer);
};

void process (string filePath, FileTailer* fileTailer);
void publishMessage(boost::shared_ptr<DataPublisher> publisher, string message);

#endif	/* FILETAILER_H */

