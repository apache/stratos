/* 
 * File:   FileTailer.cpp
 * Author: isuru
 * 
 * Created on March 17, 2013, 12:33 AM
 */

#include "FileTailer.h"

FileTailer::FileTailer(boost::shared_ptr<PublisherAgentManager> publisherAgentManager, 
                       boost::shared_ptr<SSLHandler> sslHandler,
                       list<string> files) {
    
    this->publisherAgentManager = publisherAgentManager;
    this->sslHandler = sslHandler;
    this->files = files;
    processingThreadGroup = boost::shared_ptr<boost::thread_group> (new boost::thread_group());
}

FileTailer::FileTailer(const FileTailer& orig) {
}

FileTailer::~FileTailer() {
    deallocateMemory();
}

void FileTailer::start() {
    
    list<string>::iterator it;
    for (it = files.begin() ; it != files.end() ; it++)
        processingThreadGroup->create_thread(boost::bind(process, *it, this));
    processingThreadGroup->join_all();
}

void process (string filePath, FileTailer* fileTailer) {
    
    string command = "tail -f " + filePath;
    FILE *fp = popen(command.c_str(), "r");
    if (fp == NULL) {
        printf("[ ERROR ] : Tail command failed - { %s %d } \n",  __FILE__, __LINE__);
        return;
    }
    
    boost::shared_ptr<DataPublisher> publisher (new DataPublisher(fileTailer->publisherAgentManager, 
                                                                  fileTailer->sslHandler)); 
    publisher->initialize(Configuration::getConfigurationInstance().host, 
                          Configuration::getConfigurationInstance().thriftPort, 
                          ADMIN_USERNAME, ADMIN_PASSWORD);
    
    publisher->defineStream(Configuration::getConfigurationInstance().cartridgeAlias, 
                            Configuration::getConfigurationInstance().tenantName,
                            Configuration::getConfigurationInstance().tenantId, "1.0.0");  
    
    char buffer[FILE_TAILER_BUFFER_LENGTH];
    string message;
    bool overflow = false;
    
    while (fgets(buffer, FILE_TAILER_BUFFER_LENGTH, fp) != NULL)
    {
        if(feof(fp))
        {
            //TODO: sleep for a while
            continue;
        }
        string bufferString = string(buffer);
        if(bufferString.find_last_of("/\n") == string::npos) {
            message += bufferString;
            overflow = true;
        }
        else {
            if(overflow) {
                //cout << message + bufferString;
                publishMessage(publisher, message + bufferString);
                message = "\0";
                overflow = false;
            }
            else {
                //cout << bufferString;
                publishMessage(publisher, bufferString);
            }
        }
    }

    if (pclose(fp) < 0) {
        printf("[ ERROR ] : Tail command termination failed - { %s %d } \n",  __FILE__, __LINE__);
    }
    
    publisher->stopPublishing();
}

void publishMessage (boost::shared_ptr<DataPublisher> publisher, string message) {
    
    publisher->publish(time(NULL), Configuration::getConfigurationInstance().localIpAddress, message, 
                    Configuration::getConfigurationInstance().cartridgeAlias, 
                    Configuration::getConfigurationInstance().tenantId, 
                    Configuration::getConfigurationInstance().tenantName);
}

void FileTailer::deallocateMemory() {
    processingThreadGroup.reset();
    publisherAgentManager.reset();
    sslHandler.reset();
    printf("[ INFO ] : FileTailer resources de-allocated \n");
}