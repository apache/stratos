/* 
 * File:   DataPublisher.h
 * Author: isuru
 *
 * Created on February 8, 2013, 11:57 PM
 */

#ifndef DATAPUBLISHER_H
#define	DATAPUBLISHER_H

#include <boost/shared_ptr.hpp>
#include <iostream>
#include "../manager/PublisherAgentManager.h"
#include "../ssl_handler/SSLHandler.h"

using namespace std;

class DataPublisher {
public:
    DataPublisher(boost::shared_ptr<PublisherAgentManager> publisherManager, boost::shared_ptr<SSLHandler> sslHandler);
    DataPublisher(const DataPublisher& orig);
    virtual ~DataPublisher();
    
    void initialize (string host, int port, string userName, string password);
    void defineStream (string cartridgeAlias, string tenant, int tenantId, string version);
    void publish (long timeStamp, string localIp, string data, string instance, int tenantId, string tenantName);
    void stopPublishing ();
    
private:
    int publisherId;
    int tenantId;
    boost::shared_ptr<PublisherAgentManager> publisherAgentManager;
    boost::shared_ptr<SSLHandler> sslHandler;
    
    void deallocateMemory ();
};

#endif	/* DATAPUBLISHER_H */

