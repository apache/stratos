/* 
 * File:   DataPublisher.cpp
 * Author: isuru
 * 
 * Created on February 8, 2013, 11:57 PM
 */

#include "DataPublisher.h"

DataPublisher::DataPublisher(boost::shared_ptr<PublisherAgentManager> publisherAgentManager, boost::shared_ptr<SSLHandler> sslHandler) {
    publisherId = -1;
    tenantId = -1;
    this->publisherAgentManager = publisherAgentManager;
    this->sslHandler = sslHandler;
}

DataPublisher::DataPublisher(const DataPublisher& orig) {

}

DataPublisher::~DataPublisher() {
    deallocateMemory(); 
}

void DataPublisher::initialize(string host, int port, string userName, string password) {
    publisherId = publisherAgentManager->initDataPublisher(host, port, userName, password, sslHandler);
}

void DataPublisher::defineStream(string cartridgeAlias, string tenant, int tenantId, string version) {
    if(publisherId == -1){
        //throw eror - publisher not initialized
    }
    else    
        publisherAgentManager->setStreamDefinition(publisherId, cartridgeAlias, tenant, tenantId, version);
}

void DataPublisher::publish(long timeStamp, string localIp, string data, string instance, int tenantId, string tenantName) {
    if(publisherId == -1) {
        //throw eror - publisher not initialized
    }
    else 
        publisherAgentManager->setDataToPublish(publisherId, timeStamp, localIp, data, instance, tenantId, tenantName);
}

void DataPublisher::stopPublishing() {
    publisherAgentManager->stopPublisher(publisherId);
}

void DataPublisher::deallocateMemory() {
    sslHandler.reset();
    publisherAgentManager.reset();
}

