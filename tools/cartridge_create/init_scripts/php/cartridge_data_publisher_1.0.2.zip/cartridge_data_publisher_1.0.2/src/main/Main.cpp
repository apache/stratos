/* 
 * File:   main.cpp
 * Author: isuru
 *
 * Created on December 25, 2012, 12:35 PM
 */

#include <cstdlib>
#include "../manager/PublisherAgentManager.h"
#include "../publisher/DataPublisher.h"
#include "../event_interceptor/EventInterceptor.h"
#include "../config/Configuration.h"
#include "../global_constants/Globals.h"
#include "../file_tailer/FileTailer.h"

using namespace std;

class MyAccessManager : public AccessManager {

    Decision verify( const sockaddr_storage& sa ) throw() { return ALLOW; }
    Decision verify( const string& host, const char* name, int size ) throw() { return ALLOW; }
    Decision verify( const sockaddr_storage& sa, const char* data, int size ) throw() { return ALLOW; }
};

void shutDown (int exitCode) {
    printf("[ INFO ] : Shutting down.. \n");
    exit(exitCode);
}

void runEventInterceptor () {
    printf("[ INFO ] : Starting Cartridge Data Publisher... \n");
    
    try {
        Configuration::getConfigurationInstance(); 
        
    } catch (const ConfigurationException& ex) { //TODO: fix the memory leak
        shutDown(0);
    }
    
    boost::shared_ptr<AccessManager> accessManager (new MyAccessManager());
    boost::shared_ptr<SSLHandler> sslHandler (new SSLHandler(false));
    sslHandler->initiallize(OWN_KEY, OWN_CERTIFICATE, TRUSTED_CERTIFICATE, CIPHER);
    sslHandler->setAccessManager(accessManager);
    
    boost::shared_ptr<PublisherAgentManager> publisherAgentManager (new PublisherAgentManager());
    boost::shared_ptr<EventInterceptor> interceptor (new EventInterceptor(publisherAgentManager, sslHandler));
    
    try {
        interceptor->startServer(LOG_INTERCEPTOR_PORT);
        
    } catch (const LogInteceptorException& ex) {
        
    }
    
    publisherAgentManager->shutDown();
    interceptor.reset();
    publisherAgentManager.reset();
    accessManager.reset();
    sslHandler.reset();
    shutDown(0);
}

void runFileTailer (list<string> files) {
    printf("[ INFO ] : Starting Cartridge Data Publisher... \n");
    
    try {
        Configuration::getConfigurationInstance(); 
        
    } catch (const ConfigurationException& ex) { //TODO: fix the memory leak
        shutDown(0);
    }
    
    boost::shared_ptr<AccessManager> accessManager (new MyAccessManager());
    boost::shared_ptr<SSLHandler> sslHandler (new SSLHandler(false));
    sslHandler->initiallize(OWN_KEY, OWN_CERTIFICATE, TRUSTED_CERTIFICATE, CIPHER);
    sslHandler->setAccessManager(accessManager);
    
    boost::shared_ptr<PublisherAgentManager> publisherAgentManager (new PublisherAgentManager());
 
    
    boost::shared_ptr<FileTailer> fileTailer (new FileTailer(publisherAgentManager, sslHandler, files));
    fileTailer->start();
    
    publisherAgentManager->shutDown();
    fileTailer.reset();
    publisherAgentManager.reset();
    accessManager.reset();
    sslHandler.reset();
    shutDown(0);
}

int main(int argc, char** argv) {
    
    //runEventInterceptor();
    if(argc == 1) {
        printf("[ ERROR ] : No files to tail \n");
        shutDown(0);
    }
    
    list<string> files;
    for (int i = 0 ; i < argc ; i++) {
        ifstream file(argv[i], ifstream::in);
        if(!file) {
            printf("[ WARN ] : File %s not found, will try to create it \n", argv[i]);
            ofstream newFile (argv[i]);
            newFile.close();
        }
        else
            file.close();
        files.push_back(argv[i]);
    }
    runFileTailer(files);
    
    return 0;
}

