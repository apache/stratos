/* 
 * File:   StreamInfomation.cpp
 * Author: isuru
 * 
 * Created on February 10, 2013, 10:36 AM
 */

#include "StreamInfomation.h"

StreamInfomation::StreamInfomation(string cartridgeAlias, string tenant, int tenantId, string version) {
    this->cartridgeAlias = cartridgeAlias;
    this->tenant = tenant;
    this->tenantId = tenantId;
    this->version = version;
}

StreamInfomation::StreamInfomation(const StreamInfomation& orig) {
}

StreamInfomation::~StreamInfomation() {
}

string StreamInfomation::getCartridgeAlias() const {
    return cartridgeAlias;
}

string StreamInfomation::getTenant() const {
    return tenant;
}

string StreamInfomation::getVersion() const {
    return version;
}

int StreamInfomation::getTenantId() const {
    return tenantId;
}