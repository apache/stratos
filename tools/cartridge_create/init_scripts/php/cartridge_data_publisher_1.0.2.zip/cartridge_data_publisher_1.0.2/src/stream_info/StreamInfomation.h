/* 
 * File:   StreamInfomation.h
 * Author: isuru
 *
 * Created on February 10, 2013, 10:36 AM
 */

#ifndef STREAMINFOMATION_H
#define	STREAMINFOMATION_H

#include <iostream>
#include <string>

using namespace std;

class StreamInfomation {
public:
    StreamInfomation(string cartridgeAlias, string tenant, int tenantId, string version);
    StreamInfomation(const StreamInfomation& orig);
    virtual ~StreamInfomation();
    string getCartridgeAlias() const;
    string getTenant() const;
    string getVersion () const;
    int getTenantId() const;

private:
    string cartridgeAlias;
    string tenant;
    int tenantId;
    string version;
};

#endif	/* STREAMINFOMATION_H */

