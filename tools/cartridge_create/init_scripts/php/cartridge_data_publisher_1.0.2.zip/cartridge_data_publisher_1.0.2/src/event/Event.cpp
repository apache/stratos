/* 
 * File:   Event.cpp
 * Author: isuru
 * 
 * Created on February 8, 2013, 11:53 PM
 */

#include "Event.h"

Event::Event(int publisherId, long timeStamp, string ipAddress, string message, string instance, int tenantId, string tenantName) {
    this->publisherId = publisherId;
    this->timeStamp = timeStamp;
    this->localIpAddress = ipAddress;
    this->message = message;
    this->instance = instance;
    this->tenantId = tenantId;
    this->tenantName = tenantName;
}

Event::Event(const Event& orig) {
}

Event::~Event() {
}

int Event::getPublisherId() const {
    return publisherId;
}

string Event::getMessage() const {
    return message;
}

string Event::getLocalIpAddress() const {
    return localIpAddress;
}

long Event::getTimeStamp() const {
    return timeStamp;
}

string Event::getInstance() const {
    return instance;
}

int Event::getTenantId() const {
    return tenantId;
}

string Event::getTenantName() const {
    return tenantName;
}

string Event::getTenantIdAsString() const {
    stringstream stringStream;
    stringStream << tenantId;
    return stringStream.str();
}