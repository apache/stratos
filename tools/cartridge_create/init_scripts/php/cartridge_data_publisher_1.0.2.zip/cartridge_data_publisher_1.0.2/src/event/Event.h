/* 
 * File:   Event.h
 * Author: isuru
 *
 * Created on February 8, 2013, 11:53 PM
 */

#ifndef EVENT_H
#define	EVENT_H

#include <iostream>
#include <sstream>

using namespace std;

class Event {
public:
    Event(int publisherId, long timeStamp, string ipAddress, string message, string instance, int tenantId, string tenantName);
    Event(const Event& orig);
    virtual ~Event();
    
    int getPublisherId() const;
    int getTenantId () const;
    string getTenantName () const;
    string getTenantIdAsString() const;
    string getMessage() const;
    string getLocalIpAddress() const;
    string getInstance () const;
    long getTimeStamp() const;
    
private:
    int publisherId;
    int tenantId;
    string tenantName;
    long timeStamp;
    string localIpAddress;
    string instance;
    string message;
 
};


#endif	/* EVENT_H */

