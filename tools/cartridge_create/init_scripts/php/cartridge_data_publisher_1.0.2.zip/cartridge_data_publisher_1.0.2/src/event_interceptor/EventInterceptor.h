/* 
 * File:   LogInterceptor.h
 * Author: isuru
 *
 * Created on December 29, 2012, 10:38 PM
 */

#ifndef LOGINTERCEPTOR_H
#define	LOGINTERCEPTOR_H

#include <iostream>
#include <string>
#include <errno.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <boost/algorithm/string.hpp>
#include "../publisher/DataPublisher.h"
#include "../manager/PublisherAgentManager.h"
#include "../exception/Exception.h"
#include "../config/Configuration.h"

using namespace std;

class EventInterceptor {
public:
    EventInterceptor(boost::shared_ptr<PublisherAgentManager> publisherAgentManager, 
                     boost::shared_ptr<SSLHandler> sslHandler);
    EventInterceptor(const EventInterceptor& orig);
    virtual ~EventInterceptor();
    
    void startServer(int portNo);
private:
    struct sockaddr_in serverAddress;
    //struct sockaddr_in clientAddress;
    int serverSideSocket;
    boost::shared_ptr<boost::thread_group> processingThreadGroup;
    boost::shared_ptr<PublisherAgentManager> publisherAgentManager;
    boost::shared_ptr<SSLHandler> sslHandler;
    
    void closeServerSocket ();
    void closeClientSocket (int clientSocket);
    void deallocateMemory ();
    
    friend void process (int clientSideSocket, EventInterceptor* interceptor);
};

vector<string> separateMessages(string input);
void process (int clientSideSocket, EventInterceptor* interceptor);
void publishMessage (boost::shared_ptr<DataPublisher> publisher, vector<string> msgVector);

#endif	/* LOGINTERCEPTOR_H */

