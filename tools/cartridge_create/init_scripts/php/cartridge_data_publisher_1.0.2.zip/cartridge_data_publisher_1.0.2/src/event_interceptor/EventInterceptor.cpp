/* 
 * File:   LogInterceptor.cpp
 * Author: isuru
 * 
 * Created on December 29, 2012, 10:38 PM
 */

#include "src/config/Configuration.h"


#include "EventInterceptor.h"

EventInterceptor::EventInterceptor(boost::shared_ptr<PublisherAgentManager> publisherAgentManager, 
                                   boost::shared_ptr<SSLHandler> sslHandler) {
    this->publisherAgentManager = publisherAgentManager;
    this->sslHandler = sslHandler;
    processingThreadGroup = boost::shared_ptr<boost::thread_group> (new boost::thread_group());
}

EventInterceptor::EventInterceptor(const EventInterceptor& orig) {
}

EventInterceptor::~EventInterceptor() {
    deallocateMemory();
}

void EventInterceptor::startServer(int portNo) {
    serverSideSocket = 0;
    int clientSideSocket = 0;
    struct sockaddr_in clientAddress;
    
    serverSideSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSideSocket < 0) {
        printf("[ ERROR ] : EventInterceptor socket open failed { %s %d } \n", __FILE__, __LINE__);
        closeServerSocket();
        throw LogInteceptorException("socket open failed");
    }
    else
        printf("[ INFO ] : EventInterceptor socket open successful \n"); 
    
    socklen_t clientAddressLength = sizeof(clientAddress);
    memset((char *) &serverAddress, 0, sizeof(serverAddress));
    memset((char *) &clientAddress, 0, clientAddressLength);

    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(portNo);
    
    if (::bind(serverSideSocket, (struct sockaddr *) &serverAddress, sizeof(serverAddress)) < 0) {
        printf("[ ERROR ] : EventInterceptor server socket bind failed { %s %d } \n", __FILE__, __LINE__);
        closeServerSocket();
        throw LogInteceptorException("server socket bind failed");
    } 
    else
        printf("[ INFO ] : EventInterceptor server socket bind successful \n");

    listen(serverSideSocket, SOMAXCONN); 
    
    while(true) {
        clientAddressLength = sizeof(clientAddress);
        memset((char *) &clientAddress, 0, clientAddressLength);
        clientSideSocket = accept(serverSideSocket, (struct sockaddr *) &clientAddress, &clientAddressLength);

	if (clientSideSocket < 0) {
            printf("[ ERROR ] : EventInterceptor client socket accept failed { %s %d } \n", __FILE__, __LINE__);
            continue;
        }
        else {
            printf("[ INFO ] : EventInterceptor client socket accepted, id %d \n", clientSideSocket);
            processingThreadGroup->create_thread(boost::bind(process, clientSideSocket, this));
        }
    }
    
    processingThreadGroup->join_all();
    closeServerSocket();
}


void process (int clientSideSocket, EventInterceptor* interceptor) {//needs proper shutting down and releasing thread
    
    cout << "[ INFO ] : EventInterceptor processing thread created, id " << boost::this_thread::get_id() << endl;
    int numberOfCharactersRead = 0;
    string buffer = "";
    string tempBuffer = "";
    bool overflow = false;
    
    boost::shared_ptr<DataPublisher> publisher (new DataPublisher(interceptor->publisherAgentManager, 
                                                                  interceptor->sslHandler)); 
    publisher->initialize(Configuration::getConfigurationInstance().host, 
                          Configuration::getConfigurationInstance().thriftPort, 
                          ADMIN_USERNAME, ADMIN_PASSWORD);
    publisher->defineStream(Configuration::getConfigurationInstance().cartridgeAlias, 
                            Configuration::getConfigurationInstance().tenantName,
                            Configuration::getConfigurationInstance().tenantId, "1.0.0");        
    
    do {
        char msgBuffer[LOG_INTERCEPTOR_BUFFER_LENGTH];
        memset(msgBuffer, 0, LOG_INTERCEPTOR_BUFFER_LENGTH);
        numberOfCharactersRead = recv(clientSideSocket, msgBuffer, (LOG_INTERCEPTOR_BUFFER_LENGTH - 1), 0);
        if (numberOfCharactersRead < 0) {
            printf("[ ERROR ] : EventInterceptor client socket read failed - %s { %s %d } \n", strerror(errno), __FILE__, __LINE__);
            break;
        }
        else if (numberOfCharactersRead == 0) {
            printf("[ INFO ] : EventInterceptor client side socket %d closed \n", clientSideSocket);
            break;
        }
        else {
            msgBuffer[numberOfCharactersRead] = '\0';
            cout << "[ INFO ] : Read " << numberOfCharactersRead << " bytes, thread id " << boost::this_thread::get_id() << endl;
            if (numberOfCharactersRead == (LOG_INTERCEPTOR_BUFFER_LENGTH - 1)) {
                if(overflow) {
                    buffer = tempBuffer + string(msgBuffer);
                    tempBuffer = buffer;
                }
                else {
                    tempBuffer =  string(msgBuffer);
                    overflow = true;
                }
            }
            else {
                if(overflow) {
                        string totalBuffer = tempBuffer + string(msgBuffer);
                        vector<string> output = separateMessages(totalBuffer);
                        publishMessage(publisher, output);
                }
                else {
                        vector<string> output = separateMessages(string(msgBuffer));
                        publishMessage(publisher, output);          
                }
                buffer = "";
                overflow = false;
            }
        }
    } while (numberOfCharactersRead > 0); 
    
    interceptor->closeClientSocket(clientSideSocket);
    publisher->stopPublishing();
    publisher.reset();
}

void publishMessage(boost::shared_ptr<DataPublisher> publisher, vector<string> msgVector) {//consider passing by ref    
    vector<string>::iterator it;
    for ( it = msgVector.begin() ; it != msgVector.end() ; it++ ) {
        if(!it->empty()){
            //cout << *it << endl;
            publisher->publish(time(NULL), Configuration::getConfigurationInstance().localIpAddress, *it, 
                    Configuration::getConfigurationInstance().cartridgeAlias, 
                    Configuration::getConfigurationInstance().tenantId, 
                    Configuration::getConfigurationInstance().tenantName);
        } 
    }
}

vector<string> separateMessages(string input) {    
    vector<string> strs;
    boost::split(strs, input, boost::is_any_of("\n"));
    return strs;
}

void EventInterceptor::closeServerSocket() {
    close(serverSideSocket);
    printf("[ INFO ] : EventInterceptor server socket closed \n");
}

void EventInterceptor::closeClientSocket (int clientSocket) {
    close(clientSocket);
    printf("[ INFO ] : EventInterceptor client socket %d closed \n", clientSocket);
}

void EventInterceptor::deallocateMemory() {
    processingThreadGroup.reset();
    publisherAgentManager.reset();
    sslHandler.reset();
    printf("[ INFO ] : EventInterceptor resources de-allocated \n");
}