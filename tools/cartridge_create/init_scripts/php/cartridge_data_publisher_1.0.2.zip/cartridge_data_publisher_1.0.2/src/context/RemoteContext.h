/* 
 * File:   PublisherContext.h
 * Author: isuru
 *
 * Created on February 8, 2013, 10:04 PM
 */

#ifndef REMOTECONTEXT_H
#define	REMOTECONTEXT_H

#include <iostream>
#include <string>
#include <sstream>

using namespace std;

class RemoteContext {
public:
    RemoteContext(string host, int port, string userName, string password);
    RemoteContext(const RemoteContext& orig);
    virtual ~RemoteContext();
    string getHost() const;
    int getPort() const;
    string getUserName() const;
    string getPassword() const;
private:
    string host;
    int port;
    string userName;
    string password;
    
};


#endif	/* REMOTECONTEXT_H */

