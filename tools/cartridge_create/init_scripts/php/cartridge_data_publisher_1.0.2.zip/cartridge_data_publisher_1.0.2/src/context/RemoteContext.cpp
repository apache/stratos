/* 
 * File:   PublisherContext.cpp
 * Author: isuru
 * 
 * Created on February 8, 2013, 10:04 PM
 */

#include "RemoteContext.h"

RemoteContext::RemoteContext(string host, int port, string userName, string password) {
    this->host = host;
    this->port = port;
    this->userName = userName;
    this->password = password;
}

RemoteContext::RemoteContext(const RemoteContext& orig) {
}

RemoteContext::~RemoteContext() {
}

string RemoteContext::getHost() const {
    return host;
}

int RemoteContext::getPort() const {
    return port;
}

string RemoteContext::getUserName() const {
    return userName;
}

string RemoteContext::getPassword() const {
    return password;
}


