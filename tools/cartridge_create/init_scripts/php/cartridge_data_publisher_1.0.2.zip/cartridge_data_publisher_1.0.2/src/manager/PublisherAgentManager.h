/* 
 * File:   PublisherAgentManager.h
 * Author: isuru
 *
 * Created on February 9, 2013, 12:17 AM
 */

#ifndef PUBLISHERAGENTMANAGER_H
#define	PUBLISHERAGENTMANAGER_H

#include <iostream>
#include <map>
#include <queue>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp> 
#include <boost/thread/pthread/mutex.hpp>
#include "../event/Event.h"
#include "../context/RemoteContext.h"
#include "../ssl_handler/SSLHandler.h"
#include "../stream_info/StreamInfomation.h"
#include "../global_constants/Globals.h"
#include "../event_transmitter/EventTransmissionClient.h"

using namespace std;

class PublisherAgentManager {
public:
    PublisherAgentManager();
    PublisherAgentManager(const PublisherAgentManager& orig);
    virtual ~PublisherAgentManager();
    
    int initDataPublisher (string host, int port, string userName, string password, boost::shared_ptr<SSLHandler> sslHandler);
    void setStreamDefinition (int publisherId, string cartridgeAlias, string tenant, int tenantId, string version);
    void setDataToPublish (int publisherId, long timeStamp, string localIp, string data, string instance, int tenantId, string tenantName);
    void stopPublisher (int publisherId);
    void shutDown ();
    
private:
    int dataPublisherId;
    bool shutDownTriggered;
    
    //caches
    map<int, string> streamIdCache;
    map<int, string> sessionCache;
    map<int, boost::shared_ptr<RemoteContext> > remoteContextCache; 
    map<int, boost::shared_ptr<StreamInfomation> > streamInfoCache; 
    map<string, boost::shared_ptr<SecureEventTransmitter> > eventTransmitterCache;
    map<string, boost::shared_ptr<SSLHandler> > sslHandlerCache;
    
    //event queue
    queue<boost::shared_ptr<Event> > eventQueue;
        
    //locking for thread safety
    boost::mutex eventQueueMutex;
    boost::mutex eventTransmitterCacheMutex;
    boost::mutex sessionCacheMutex;
    boost::mutex streamIdCacheMutex;
    boost::mutex sslHandlerCacheMutex;
    boost::mutex remoteContextCacheMutex;
    boost::mutex streamInfoCacheMutex;
    //thread for publishing
    boost::shared_ptr<boost::thread> publisherThread;
    
    string getStreamId (int dataPublisherId);
    string getSessionId (int dataPublisherId);
    bool getStreamInfomation (boost::shared_ptr<StreamInfomation>& streamInfo, int dataPublisherId);
    bool getRemoteContext (boost::shared_ptr<RemoteContext>& remoteCtx, int dataPublisherId);
    bool getSSLHandler (boost::shared_ptr<SSLHandler>& sslHandler, string host);
    bool getEventTransmitter (boost::shared_ptr<SecureEventTransmitter>& client, string host);
    string getDate ();
    boost::shared_ptr<SecureEventTransmitter> createEventTransmitter (boost::shared_ptr<SSLHandler> sslHandler, 
                                                                      boost::shared_ptr<RemoteContext> remoteCtx, bool secure);
    string createSession (boost::shared_ptr<SecureEventTransmitter> transmitter);
    string createStreamId (string& sessionId, string streamDef, boost::shared_ptr<SecureEventTransmitter> transmitter);
    void cacheEventTransmitter (string host, 
                                boost::shared_ptr<SecureEventTransmitter> transmitter);
    void cacheSession (int publisherId, string session);
    void clearCachedSession (int publisherId);
    bool isNewSession (string localSessionId, string sessionId);
    void cacheStreamId (int publisherId, string streamId);
    void clearCachedStreamId (int publisherId);
    void openEventTransmissionSocket(boost::shared_ptr<SecureEventTransmitter> transmitter);
    void openEventTransmissionTransport(boost::shared_ptr<SecureEventTransmitter> transmitter);
    string createStreamDefinition (boost::shared_ptr<StreamInfomation> streamInfo);
    void publishEvent (boost::shared_ptr<SecureEventTransmitter> transmitter, 
                       boost::shared_ptr<Event> event, 
                       string& sessionId, string streamId);
    void clearCachedRemoteContext (int publisherId);
    void clearCachedStreamInformation (int publisherId);
    void completePublishing ();
    
    friend void runPublisherTask (PublisherAgentManager* manager);
};

void runPublisherTask (PublisherAgentManager* manager);
string toString (int integer);

#endif	/* PUBLISHERAGENTMANAGER_H */

