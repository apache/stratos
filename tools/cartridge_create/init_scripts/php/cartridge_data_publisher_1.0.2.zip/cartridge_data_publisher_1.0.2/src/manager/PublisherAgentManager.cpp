/* 
 * File:   PublisherAgentManager.cpp
 * Author: isuru
 * 
 * Created on February 9, 2013, 12:17 AM
 */

#include "PublisherAgentManager.h"


PublisherAgentManager::PublisherAgentManager() {
    dataPublisherId = 0;
    shutDownTriggered = false;
    publisherThread = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(runPublisherTask, this)));
}

PublisherAgentManager::PublisherAgentManager(const PublisherAgentManager& orig) {
}

PublisherAgentManager::~PublisherAgentManager() {
    publisherThread.reset(); 
}

int PublisherAgentManager::initDataPublisher(string host, int port, string userName, string password, boost::shared_ptr<SSLHandler> sslHandler) {
    boost::shared_ptr<RemoteContext> remoteCtx (new RemoteContext(host, port, userName, password));
    boost::mutex::scoped_lock sslHandlerCacheLock(sslHandlerCacheMutex); 
    sslHandlerCache.insert(pair<string, boost::shared_ptr<SSLHandler> >(remoteCtx->getHost(), sslHandler));
    sslHandlerCacheLock.unlock();
    
    boost::mutex::scoped_lock remoteCtxCacheLock(remoteContextCacheMutex);
    remoteContextCache.insert(pair<int, boost::shared_ptr<RemoteContext> >(++dataPublisherId, remoteCtx));
    return dataPublisherId;
}

void PublisherAgentManager::setStreamDefinition(int publisherId, string cartridgeAlias, string tenant, int tenantId, string version) {
    boost::shared_ptr<StreamInfomation> streamInfo (new StreamInfomation(cartridgeAlias, tenant, tenantId, version));
    boost::mutex::scoped_lock lock(streamInfoCacheMutex);
    streamInfoCache.insert(pair<int, boost::shared_ptr<StreamInfomation> >(publisherId, streamInfo));
}

void PublisherAgentManager::setDataToPublish(int publisherId, long timeStamp, string localIp, string data, string instance, int tenantId, string tenantName) {
    boost::shared_ptr<Event> event (new Event(publisherId, timeStamp, localIp, data, instance, tenantId, tenantName));
    boost::mutex::scoped_lock lock(eventQueueMutex);
    eventQueue.push(event);
}

void PublisherAgentManager::shutDown() {
    shutDownTriggered = true;
    completePublishing();
    
    //terminate all sessions, clear caches
}

void PublisherAgentManager::completePublishing() {
    publisherThread->join();
}

bool PublisherAgentManager::getRemoteContext(boost::shared_ptr<RemoteContext>& remoteCtx, int dataPublisherId) {
    map<int, boost::shared_ptr<RemoteContext> >::iterator it;
    it = remoteContextCache.find(dataPublisherId);
    if (it == remoteContextCache.end())
        return false;
    remoteCtx = it->second;
    return true;
}

bool PublisherAgentManager::getEventTransmitter(boost::shared_ptr<SecureEventTransmitter>& client, string host) {
    map<string, boost::shared_ptr<SecureEventTransmitter> >::iterator it;
    it = eventTransmitterCache.find(host);
    if (it == eventTransmitterCache.end())
        return false;
    client = it->second;
    return true;
}

bool PublisherAgentManager::getSSLHandler(boost::shared_ptr<SSLHandler>& sslHandler, string host) {
    map<string ,boost::shared_ptr<SSLHandler> >::iterator it;
    it = sslHandlerCache.find(host);
    if (it == sslHandlerCache.end())
        return false;
    sslHandler = it->second;
    return true;
}

bool PublisherAgentManager::getStreamInfomation(boost::shared_ptr<StreamInfomation>& streamInfo, int dataPublisherId) {
    map<int, boost::shared_ptr<StreamInfomation> >::iterator it;
    it = streamInfoCache.find(dataPublisherId);
    if (it == streamInfoCache.end())
        return false;
    streamInfo = it->second;
    return true;   
}

string PublisherAgentManager::getSessionId(int dataPublisherId) {
    map<int, string>::iterator it = sessionCache.find(dataPublisherId);
    return (it != sessionCache.end() ? it->second : "");
}

string PublisherAgentManager::getStreamId(int dataPublisherId) {
    map<int, string>::iterator it = streamIdCache.find(dataPublisherId);
    return (it != streamIdCache.end() ? it->second : "");
}

boost::shared_ptr<SecureEventTransmitter> PublisherAgentManager::createEventTransmitter(boost::shared_ptr<SSLHandler> sslHandler,
                                                                                        boost::shared_ptr<RemoteContext> remoteCtx, bool secure) {
    boost::shared_ptr<SecureEventTransmitter> transmitter;
    if (secure) {
        transmitter = boost::shared_ptr<SecureEventTransmitter>(new SecureEventTransmitter(sslHandler, remoteCtx));
    } else {
        //TODO
    }
    return transmitter;
}

void PublisherAgentManager::cacheEventTransmitter(string host,
                                                  boost::shared_ptr<SecureEventTransmitter> transmitter) {
    boost::mutex::scoped_lock lock(eventTransmitterCacheMutex);
    eventTransmitterCache.insert(pair<string, boost::shared_ptr<SecureEventTransmitter> >(host, transmitter));
}

string PublisherAgentManager::createSession(boost::shared_ptr<SecureEventTransmitter> transmitter) {
    return transmitter->createSession();
}

void PublisherAgentManager::cacheSession(int publisherId, string session) {
    boost::mutex::scoped_lock lock(sessionCacheMutex);
    sessionCache.insert(pair<int ,string>(publisherId, session));
}

string PublisherAgentManager::createStreamDefinition(boost::shared_ptr<StreamInfomation> streamInfo) { 
    string columnFamilyName =  STREAMDEF_PREFIX + "_" 
            + toString(streamInfo->getTenantId()) + "_"
            + streamInfo->getCartridgeAlias() + "_"
            + getDate();
    string version = streamInfo->getVersion();
    
    return "{ 'name':'" + columnFamilyName + "', 'version':'" + version + "', "
            
            "'metaData':[ " +
                          "{'name':'tenant','type':'STRING'} " +
                       "], " +
            
            "'payloadData':[ " +
                             "{'name':'tenantID','type':'STRING'}, " +
                             "{'name':'serverName','type':'STRING'}, " +
                             "{'name':'appName','type':'STRING'}, " + //replace with cartridge alias
                             "{'name':'logTime','type':'LONG'}, " +
                             "{'name':'priority','type':'STRING'}, " +
                             "{'name':'message','type':'STRING'}, " +
                             "{'name':'logger','type':'STRING'}, " +
                             "{'name':'ip','type':'STRING'}, " +
                             "{'name':'instance','type':'STRING'}, " +
                             "{'name':'stacktrace','type':'STRING'} " +
                          "] " +
            "}";
}

string PublisherAgentManager::getDate() {
    
    time_t t = time(0);
    struct tm * now = localtime(&t);
    
    string thisMonth;
    if((now->tm_mon + 1) < 10)
        thisMonth = "0" + toString(now->tm_mon + 1);
    else
        thisMonth = toString(now->tm_mon + 1);
    
    string today;
    if((now->tm_mday) < 10)
        today = "0" + toString(now->tm_mday);
    else
        today = toString(now->tm_mday);
    
    return toString(now->tm_year + 1900) + "_" + thisMonth + "_" + today;
}

string PublisherAgentManager::createStreamId(string& sessionId, string streamDef, boost::shared_ptr<SecureEventTransmitter> transmitter) {
    return transmitter->defineStream(sessionId, streamDef);
}

void PublisherAgentManager::cacheStreamId(int publisherId, string streamId) {
    boost::mutex::scoped_lock lock(streamIdCacheMutex);
    streamIdCache.insert(pair<int, string>(publisherId, streamId));
}

void PublisherAgentManager::publishEvent(boost::shared_ptr<SecureEventTransmitter> transmitter, boost::shared_ptr<Event> event, string& sessionId, string streamId) {
    transmitter->publishEvent(event, sessionId, streamId);
}

bool PublisherAgentManager::isNewSession(string currentSessionId, string newSessionId) {
    return (currentSessionId.compare(newSessionId) != 0);
}

void PublisherAgentManager::stopPublisher(int publisherId) {
    boost::shared_ptr<RemoteContext> remoteCtx;
    boost::shared_ptr<SecureEventTransmitter> transmitter;
    
    if(!getRemoteContext(remoteCtx, publisherId)) {
        //ctx does not exist
        return;
    }
    
    if(!getEventTransmitter(transmitter, remoteCtx->getHost())) {
        //transmitter does not exist
        return;
    }
    
    string sessionId = getSessionId(publisherId);
    transmitter->terminateSession(sessionId);
    
    clearCachedStreamInformation(publisherId);
    clearCachedStreamId(publisherId);
    clearCachedSession(publisherId);
    clearCachedRemoteContext(publisherId);
}

void PublisherAgentManager::clearCachedStreamInformation(int publisherId) {
    boost::mutex::scoped_lock lock(streamInfoCacheMutex);
    streamInfoCache.erase(publisherId);
}

void PublisherAgentManager::clearCachedStreamId(int publisherId) {
    boost::mutex::scoped_lock lock(streamIdCacheMutex);
    streamIdCache.erase(publisherId);
}

void PublisherAgentManager::clearCachedSession(int publisherId) {
    boost::mutex::scoped_lock lock(sessionCacheMutex);
    sessionCache.erase(publisherId);
}

void PublisherAgentManager::clearCachedRemoteContext(int publisherId) {
    boost::mutex::scoped_lock lock(remoteContextCacheMutex);
    remoteContextCache.erase(publisherId);
}

void runPublisherTask(PublisherAgentManager* manager) {
    
    int emptyIterationCount = 0;
    int sleepTime = 0;
    
    while (true) {     
        boost::mutex::scoped_lock lock(manager->eventQueueMutex);
        if(manager->eventQueue.empty()){
            lock.unlock();
            
            if(manager->shutDownTriggered)
                break;
            
            if(emptyIterationCount <= 4) {
                emptyIterationCount++;
                sleepTime = 2 * emptyIterationCount;
            }
            
            boost::system_time time = boost::get_system_time();
            time += boost::posix_time::seconds(sleepTime); 
            boost::this_thread::sleep(time);
            
        } else {   
            if(emptyIterationCount > 0)
                emptyIterationCount = 0;
            boost::shared_ptr<Event> event = manager->eventQueue.front();
            manager->eventQueue.pop();
            lock.unlock();
            int publisherId = event->getPublisherId();
                
            boost::shared_ptr<RemoteContext> remoteCtx;
            boost::shared_ptr<SSLHandler> sslHandler;
            boost::shared_ptr<StreamInfomation> streamInfo;
            boost::shared_ptr<SecureEventTransmitter> transmitter;
            string sessionId;
            string streamId;
            
            if(!manager->getRemoteContext(remoteCtx, publisherId) || 
               !manager->getSSLHandler(sslHandler, remoteCtx->getHost())     ||
               !manager->getStreamInfomation(streamInfo, publisherId)) {
                //TODO: can't happen - error, skip iteration
                
            } else {
                    //cout << "Remote Context Cache Size: " << manager->remoteContextCache.size() << endl;
                    //cout << "SSL Handler Cache Size: " << manager->sslHandlerCache.size() << endl;
                    //cout << "Stream Info Cache Size: " << manager->streamInfoCache.size() << endl;
                
                if (!manager->getEventTransmitter(transmitter, remoteCtx->getHost())) {
                    transmitter = manager->createEventTransmitter(sslHandler, remoteCtx, true);
                    manager->cacheEventTransmitter(remoteCtx->getHost(), transmitter);
                } 
                //cout << "Event Transmitter Cache Size: " << manager->eventTransmitterCache.size() << endl;
                
                sessionId = manager->getSessionId(publisherId);
                if(sessionId.empty()) {   
                    sessionId = manager->createSession(transmitter);                 
                    manager->cacheSession(publisherId, sessionId);
                } 
                //cout << "Session Cache Size: " << manager->sessionCache.size() << endl;
                
                streamId =  manager->getStreamId(publisherId);
                if(streamId.empty()) {
                    string streamDef = manager->createStreamDefinition(streamInfo); 
                    string tempSessionIdCopy = sessionId;
                    streamId = manager->createStreamId(sessionId, streamDef, transmitter);
                    if(manager->isNewSession(tempSessionIdCopy, sessionId)) { 
                        manager->clearCachedSession(publisherId);
                        manager->cacheSession(publisherId, sessionId);
                    }
                    manager->cacheStreamId(publisherId, streamId);
                }
                //cout << "Stream Id Cache Size: " << manager->streamIdCache.size() << endl;
            }
            string tempSessionIdCopy = sessionId;
            manager->publishEvent(transmitter, event, sessionId, streamId);   
            if(manager->isNewSession(tempSessionIdCopy, sessionId)) {
                manager->clearCachedSession(publisherId);
                manager->cacheSession(publisherId, sessionId);
            }
        }
    }
    
}

string toString (int integer) {
    stringstream stringStream;
    stringStream << integer;
    return stringStream.str();
}

