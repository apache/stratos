#include "Globals.h"

//configuration file 
const string CONF_FILE_PATH = "../../../conf/data_publisher.conf";

//ssl
const string OWN_KEY = "../../../security/keys/publisher/data-publisher-key-pair.pem";
const string OWN_CERTIFICATE = "../../../security/keys/publisher/data-publisher-cert.cer";
const string TRUSTED_CERTIFICATE = "../../../security/keys/bam/bam-public-cert.cer";
//const string TRUSTED_CERTIFICATE = "../../../security/keys/bam/keys_march_7/bam_public_cert.cer";
const string CIPHER = "HIGH:!DSS:!aNULL@STRENGTH";

//credentials for BAM
const string ADMIN_USERNAME = "admin";
const string ADMIN_PASSWORD = "admin";

//misc
const int LOG_INTERCEPTOR_BUFFER_LENGTH = 1500;
const int FILE_TAILER_BUFFER_LENGTH = 1500;
const int REATTEMPTS = 3;
const int LOG_INTERCEPTOR_PORT = 32000;

//stream definition constants
const string STREAMDEF_PREFIX = "log";
