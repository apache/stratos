/* 
 * File:   Globals.h
 * Author: isuru
 *
 * Created on January 9, 2013, 10:52 AM
 */

#ifndef GLOBALS_H
#define	GLOBALS_H

#include <iostream>
#include <string>

using namespace std;

extern const int LOG_INTERCEPTOR_BUFFER_LENGTH;
extern const int FILE_TAILER_BUFFER_LENGTH;
extern const int LOG_INTERCEPTOR_PORT;
extern const int REATTEMPTS;
extern const string CONF_FILE_PATH;
extern const string OWN_KEY;
extern const string OWN_CERTIFICATE;
extern const string TRUSTED_CERTIFICATE;
extern const string CIPHER;
extern const string ADMIN_USERNAME;
extern const string ADMIN_PASSWORD;
extern const string STREAMDEF_PREFIX;

#endif	/* GLOBALS_H */

