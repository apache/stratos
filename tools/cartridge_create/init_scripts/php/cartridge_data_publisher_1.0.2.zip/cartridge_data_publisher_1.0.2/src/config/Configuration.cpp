/* 
 * File:   Configuration.cpp
 * Author: isuru
 * 
 * Created on January 8, 2013, 7:00 PM
 */

#include "Configuration.h"

Configuration::Configuration() {
        
    host = "";
    thriftPort = DEFAULT_THRIFT_PORT;
    cartridgeAlias = "";
    tenantName = "";
    tenantId = DEFAULT_TENANT_ID;
    readConfigFile();
    populateData();
}

Configuration::Configuration(const Configuration& orig) {
}

Configuration::~Configuration() {
}

Configuration& Configuration::getConfigurationInstance() {
    
    static Configuration config;
    return config;       
}

void Configuration::readConfigFile() {
    
    ifstream fileInStream (CONF_FILE_PATH.c_str() , ifstream::in);
    if(fileInStream.fail()) {
        printf("[ ERROR ] : Failed to open configuration file - { %s %d } \n", __FILE__, __LINE__);
        fileInStream.close();
        throw ConfigurationException("Failed to open configuration file");
    }
    
    string line;
    while (getline(fileInStream, line)) {
        if(!line.empty() && line.at(0) != '#') {
            size_t position = line.find(":");
            string param, value;
            param = line.substr(0, position);
            value = line.substr(position + 1);
            boost::trim(param);
            boost::trim(value);
            configParamMap.insert(make_pair<string, string>(param, value)); 
        }
    }
    fileInStream.close();  
}

void Configuration::populateData() {
    
    if(configParamMap.empty()) {
        printf("[ ERROR ] : Empty configuration file - { %s %d } \n", __FILE__, __LINE__);
        throw ConfigurationException("Empty configuration file");
    }
    
    map<string, string>::iterator it;
    it = configParamMap.find("host");
    if(it == configParamMap.end()) { 
        printf("[ ERROR ] : No entry found for hostName in configuration file - { %s %d } \n", __FILE__, __LINE__);
        throw ConfigurationException("No entry found for hostName in configuration file");
    }
    else
        this->host = it->second;
    
    it = configParamMap.find("thriftPort");
    if(it == configParamMap.end()) {
        printf("[ WARN ] : No entry found for thriftPort in configuration file, using default thrift port %d", DEFAULT_THRIFT_PORT);
    }
    else
        this->thriftPort = atoi(it->second.c_str());
    
    it = configParamMap.find("cartridgeAlias");
    if(it == configParamMap.end()) {
        printf("[ ERROR ] : No entry found for cartridgeAlias in configuration file - { %s %d } \n", __FILE__, __LINE__);
        throw ConfigurationException("No entry found for cartridgeAlias in configuration file");
    }
    else
        this->cartridgeAlias = it->second;
    
    it = configParamMap.find("tenantName");
    if(it == configParamMap.end()) { 
        printf("[ ERROR ] : No entry found for tenantName in configuration file - { %s %d } \n", __FILE__, __LINE__);
        throw ConfigurationException("No entry found for tenantName in configuration file");
    }
    else
        this->tenantName = it->second;
    
    it = configParamMap.find("localIP");
    if(it == configParamMap.end()) {
        printf("[ ERROR ] : No entry found for localIP in configuration file - { %s %d } \n", __FILE__, __LINE__);
        throw ConfigurationException("No entry found for localIP in configuration file");
    }
    else
        this->localIpAddress = it->second;
    
    it = configParamMap.find("tenantId");
    if(it == configParamMap.end()) {
        printf("[ WARN ] : No entry found for tenantId in configuration file, using the default tenant Id %d", DEFAULT_TENANT_ID);
    }
    else
        this->tenantId = atoi(it->second.c_str());
}

