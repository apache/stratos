/* 
 * File:   Configuration.h
 * Author: isuru
 *
 * Created on January 8, 2013, 7:00 PM
 */

#ifndef CONFIGURATION_H
#define	CONFIGURATION_H

#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <sstream>
#include <boost/algorithm/string.hpp>
#include "../global_constants/Globals.h"
#include "../exception/Exception.h"

#define DEFAULT_THRIFT_PORT 7711
#define DEFAULT_TENANT_ID 0

using namespace std;

class Configuration {
public:
    virtual ~Configuration();
    
    //BAM configs
    string host;
    int thriftPort;
    
    //tenant configs
    string cartridgeAlias;
    string tenantName;
    int tenantId;
    
    //local configs
    string localIpAddress;
   
    static Configuration& getConfigurationInstance ();
    
private:

    //configuration map
    map<string, string> configParamMap;
    Configuration();
    Configuration(const Configuration& orig);
    
    void readConfigFile ();
    void populateData ();
};

#endif	/* CONFIGURATION_H */

