/* 
 * File:   LogInteceptorException.h
 * Author: isuru
 *
 * Created on December 29, 2012, 11:07 PM
 */

#ifndef LOGINTECEPTOREXCEPTION_H
#define	LOGINTECEPTOREXCEPTION_H

#include <iostream>
#include <exception>
 
using namespace std;

class LogInteceptorException : public exception{
public:
    LogInteceptorException(const char* errMessage) throw();
    LogInteceptorException(const LogInteceptorException& orig);
    virtual ~LogInteceptorException() throw();
    
    const char* what() const throw();
private:
    const char* exceptionMessage;
};

class ConfigurationException : public exception{
public:
    ConfigurationException(const char* errMessage) throw();
    ConfigurationException(const ConfigurationException& orig);
    virtual ~ConfigurationException() throw();
    
    const char* what() const throw();
private:
    const char* exceptionMessage;
};

#endif	/* LOGINTECEPTOREXCEPTION_H */

