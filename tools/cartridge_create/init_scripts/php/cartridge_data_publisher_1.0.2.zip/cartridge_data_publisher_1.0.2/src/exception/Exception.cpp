/* 
 * File:   LogInteceptorException.cpp
 * Author: isuru
 * 
 * Created on December 29, 2012, 11:07 PM
 */

#include "Exception.h"

/*
 * LogInteceptorException implementation
 */

LogInteceptorException::LogInteceptorException(const char* errMessage) throw()
                                              : exceptionMessage (errMessage) {
}

LogInteceptorException::LogInteceptorException(const LogInteceptorException& orig) {
}

LogInteceptorException::~LogInteceptorException() throw() {
}

const char* LogInteceptorException::what() const throw() {
    return exceptionMessage;
}

/*
 * ConfigurationException implementation
 */

ConfigurationException::ConfigurationException(const char* errMessage) throw()
                                              : exceptionMessage (errMessage) {
}

ConfigurationException::ConfigurationException(const ConfigurationException& orig) {
}

ConfigurationException::~ConfigurationException() throw() {
}

const char* ConfigurationException::what() const throw() {
    return exceptionMessage;
}